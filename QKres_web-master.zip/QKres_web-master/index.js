document.addEventListener('DOMContentLoaded',function(){
  $('.Search i').on('click',function(){
    $('.Search').toggleClass('active')
  })
})
